module.exports.function = function writeFootprints ($vivContext,fname, point, profile, namewrite) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');

  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };

  var dates = require('dates');
  var zone = new dates.ZonedDateTime($vivContext.timezone);
  var fdate = zone.getYear()+"-"+zone.getMonth()+"-"+zone.getDay();
  var ftime = zone.getHour()+":"+zone.getMinute()+":"+zone.getSecond();
  var resultData = zone.getYear()+"년 "+zone.getMonth()+"월 "+zone.getDay()+"일 "+zone.getHour()+"시"+zone.getMinute()+"분";

  var footprintsParams = {
    "uemail": profile.email,
    "fname": fname,
    "fdate": fdate,
    "ftime": ftime,
    "flocation1": point.point.latitude,
    "flocation2": point.point.longitude
  }; 


  let writeData = http.postUrl(baseUrl+'addFootprints.php', footprintsParams, options);

  var success = writeData.response[0].success;

  if(success == 'nottraveling'){
      return {
        errorflag : 'nottraveling'
    }
  }

  return {
      errorflag : 'ok',
      fid : writeData.response[1].fid,
      fname : writeData.response[1].fname,
      fdate : writeData.response[1].fdate,
      flocation1 : writeData.response[1].flocation1,
      flocation2 : writeData.response[1].flocation2,
      point : {
        point: {
          latitude : writeData.response[1].flocation1,
          longitude : writeData.response[1].flocation2
        }
      },
      ftid : writeData.response[1].ftid,
      ficon : writeData.response[1].ficon
  }
}
