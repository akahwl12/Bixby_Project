module.exports.function = function openWebSite () {

  return 'http://footprintss.cf';

}
