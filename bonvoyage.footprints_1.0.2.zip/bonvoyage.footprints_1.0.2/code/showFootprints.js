module.exports.function = function showFootprints ($vivContext, profile, TravelStructure) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };
  console.log(TravelStructure);
  var footprintsParams = {
    "tid" : TravelStructure.travelId
  }; 

  let data = http.postUrl(baseUrl+'getFootprintsBytid.php', footprintsParams, options);

  var res = [];
  var success = data.response[0].success;
  var len = data.response[0].length;

  for(var i = 1; i <= len; i++){
    var fdate = data.response[i].fdate;
    var fd = fdate.split(' ')[0];
    var ft = fdate.split(' ')[1];

    fdate = fd.substring(0,4) + "년 " + fd.substring(5,7) + "월 " 
                    + fd.substring(8,10) + "일 " + ft.substring(0,2) + "시 " + ft.substring(3,5) + "분";

    res[i-1] = {
      errorflag : "ok",
      fid : data.response[i].fid,
      fname : data.response[i].fname,
      fdate : fdate,
      flocation1 : data.response[i].flocation1,
      flocation2 : data.response[i].flocation2,
      point : {
        point: {
          latitude : data.response[i].flocation1,
          longitude : data.response[i].flocation2
        }
      },
      ftid : data.response[i].ftid,
      ficon : data.response[i].ficon
    }
  }
  console.log(res);
  return res;
}
