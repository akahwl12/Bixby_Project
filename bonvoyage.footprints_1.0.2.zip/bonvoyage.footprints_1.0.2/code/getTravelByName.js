module.exports.function = function getTravelByName ($vivContext, profile, travelName, nameview) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };
  console.log(travelName);

  var travelParams = {
    "tname" : travelName,
    "uemail" : profile.email
  }; 

  let travelData = http.postUrl(baseUrl+'getTravelListByName.php', travelParams, options);

  var res = [];
  var success = travelData.response[0].success;
  var len = travelData.response[0].length;
  for(var i = 1; i <= len; i++){
    var startdate = travelData.response[i].tstartdate;
    var enddate = travelData.response[i].tenddate;

    if(enddate == 'null'){
      enddate = '여행중'
    }
    res[i] = {
      travelId : travelData.response[i].tid,
      travelName : travelData.response[i].tname,
      travelStartDate : startdate,
      travelEndDate : enddate
    }
  }
  return res;
}
