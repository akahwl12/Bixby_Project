module.exports.function = function showTravelList2 ($vivContext, profile, nameview) {
   // 여행 목록 불러오기
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };

  var travelParams = {
    "uemail" : profile.email
  }; 

  let travelData = http.postUrl(baseUrl+'getTravelList2.php', travelParams, options);

  //response = http.getUri(baseUri+'/testjson2.php', {format: 'json'});
  //var data = require('/data/traveldata.js');
  //data = data[0];

  var res = [];
  var success = travelData.response[0].success;
  var len = travelData.response[0].length;
  for(var i = 1; i <= len; i++){
    var enddate = travelData.response[i].tenddate;
    var startdate = travelData.response[i].tstartdate;
    if(enddate == 'null'){
      enddate = '여행중'
    }
    else {
      var edate = enddate.split(' ')[0];
      var etime = enddate.split(' ')[1];
      enddate = edate.substring(0,4) + "년 " + edate.substring(5,7) + "월 " 
                    + edate.substring(8,10) + "일";
    }
    var sdate = startdate.split(' ')[0];
    var stime = startdate.split(' ')[1];

    startdate = sdate.substring(0,4) + "년 " + sdate.substring(5,7) + "월 " 
                    + sdate.substring(8,10) + "일";

    res[i] = {
      travelId : travelData.response[i].tid,
      travelName : travelData.response[i].tname,
      travelStartDate : startdate,
      travelEndDate : enddate,
      ticon : travelData.response[i].ticon
    }
  }
  return res;

}
