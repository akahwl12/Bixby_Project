module.exports.function = function getTravelIcon ($vivContext, profile, travelStructure) {
    // 여행 목록 불러오기
  const console = require('console');
  const config = require('config');
  const http = require('http');
  const fail = require('fail');

  const baseUri = config.get("baseUri");

  let response = null;

  //response = http.getUri(baseUri+'/testjson2.php', {format: 'json'});
  var data = require('/data/IconData.js');
  data = data[0];

  var res = [];
  var success = data.response[0].success;
  var len = data.response[0].length;
  for(var i = 1; i <= len; i++){
    res[i] = {
      travelId : travelStructure.travelId,
      iconName : data.response[i].name,
      iconFileName : data.response[i].filename,
      imageUrl : data.response[i].url
    }
  }
  return res;
}
