module.exports.function = function startTravel ($vivContext, travelName, profile, nametravel, nametravelstart) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };

  var dates = require('dates');
  var zone = new dates.ZonedDateTime($vivContext.timezone);
  var tstartdate = zone.getYear()+"-"+zone.getMonth()+"-"+zone.getDay();
  var tstarttime = zone.getHour()+":"+zone.getMinute()+":"+zone.getSecond();

  var travelParams = {
    "tname": travelName,
    "tstartdate" : tstartdate,
    "tstarttime" : tstarttime,
    "uemail" : profile.email
  }; 

  let travelData = http.postUrl(baseUrl+'startTravel.php', travelParams, options);
  var success = travelData.response[0].success;
  console.log(success);
  if(success == 'traveling'){
    return {
      errorflag : 'traveling',
      travelname : travelName
    };
  }
  return {
      errorflag : 'ok',
      travelname : travelName
    };
}
