module.exports.function = function endTravel ($vivContext, profile, nametravel, nametravelend) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };

  var dates = require('dates');
  var zone = new dates.ZonedDateTime($vivContext.timezone);
  var tenddate = zone.getYear()+"-"+zone.getMonth()+"-"+zone.getDay();
  var tendtime = zone.getHour()+":"+zone.getMinute()+":"+zone.getSecond();

  var travelParams = {
    "uemail" : profile.email,
    "tenddate" : tenddate,
    "tendtime" : tendtime
  }; 

  let travelData = http.postUrl(baseUrl+'endTravel.php', travelParams, options);
  var success = travelData.response[0].success;
  console.log(travelData);
  if(success == 'nottraveling'){
    return {
    errorflag : "nottraveling"
    };
  }

  var startdate = travelData.response[1].tstartdate;
  var sdate = startdate.split(' ')[0];
  startdate = sdate.substring(0,4) + "년 " + sdate.substring(5,7) + "월 " 
                    + sdate.substring(8,10) + "일";

  var enddate = travelData.response[1].tenddate;
  var edate = enddate.split(' ')[0];
  enddate = edate.substring(0,4) + "년 " + edate.substring(5,7) + "월 " 
                    + edate.substring(8,10) + "일";

  return {
    errorflag : "ok",
    travelId : travelData.response[1].tid,
    travelName : travelData.response[1].tname,
    travelStartDate : startdate,
    travelEndDate : enddate
  };

}
