module.exports.function = function getProfile ($vivContext) {
  if($vivContext.accessToken == null){
    return '로그인토큰없음';
  }
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  console.log($vivContext);

  var target= "https://www.googleapis.com/oauth2/v1/userinfo";

  const response = http.oauthGetUrl(target, {format:"json", cacheTime: 0, returnHeaders:true});
  console.log(response);
  var profile = response.parsed;
  console.log(profile);
  if(response.status != 200){
    return '데이터 받아오기 실패 아마 재인증?';
  }

 console.log("ㅎㅎ");
  var params = {
    "uemail": profile.email,
    "uname" : profile.name
  }; 

  

  http.postUrl(baseUrl+'addUser.php', params);

  return {
    "email" : profile.email,
    "name" : profile.name
  };
}
