
module.exports.function = function getLocationInfo (point) {
  const console = require('console');
  
  let result = [];
  let mem = {
    point:{
      latitude: point.point.latitude,
      longitude: point.point.longitude
    }
  }  
  result.push(mem)

  return result;
}
