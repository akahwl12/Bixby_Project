module.exports.function = function changeTravelIcon ($vivContext, profile, travelIconResult) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };

  var params = {
    "tid" : travelIconResult.travelId,
    "ticon" : travelIconResult.iconFileName
  }; 
  let data = http.postUrl(baseUrl+'updateTicon.php', params, options);
  var success = data.response[0].success;

  console.log(data.response[1].ticon);

  var endDate = data.response[1].tenddate;
  if(endDate==null) {
    endDate = "여행중";
  }

  return {
    travelId : data.response[1].tid,
    travelName : data.response[1].tname,
    travelStartDate : data.response[1].tstartdate,
    travelEndDate : endDate,
    ticon : data.response[1].ticon
  };
}
