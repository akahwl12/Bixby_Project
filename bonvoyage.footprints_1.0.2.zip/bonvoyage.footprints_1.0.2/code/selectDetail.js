module.exports.function = function getDetail (TravelResult) {
  // 여행 목록 불러오기
  const console = require('console');
  const config = require('config');
  const http = require('http');
  const fail = require('fail');

  const baseUri = config.get("baseUri");

  let response = null;

  //response = http.getUri(baseUri+'/testjson2.php', {format: 'json'});

  var res = undefined;
  res = {
    travelId : TravelResult.travelId,
    travelName : TravelResult.travelName,
    travelStartDate : TravelResult.travelStartDate,
    travelEndDate : TravelResult.travelEndDate
  }

  console.log(res);

  return res;
}
