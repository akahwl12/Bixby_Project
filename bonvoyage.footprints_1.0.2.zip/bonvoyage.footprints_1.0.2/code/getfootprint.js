module.exports.function = function getfootprint (DetailResult) {
  // 발자취 목록 불러오기
  const console = require('console');
  const config = require('config');
  const http = require('http');
  const fail = require('fail');

  const baseUri = config.get("baseUri");

  let response = null;

  //response = http.getUri(baseUri+'/testjson2.php', {format: 'json'});
  var data = require('/data/footprintdata.js');
  data = data[0];

  var res = [];
  var idx = 0;

  console.log(DetailResult)

  if(DetailResult==undefined) {
    var success = data.response[0].success;
    var len = data.response[0].length;
    for(var i = 1; i <= len; i++){
      res[i] = {
        errorflag : "ok",
        fid : data.response[i].fid,
        fname : data.response[i].fname,
        fdate : data.response[i].fdate,
        flocation1 : data.response[i].flocation1,
        flocation2 : data.response[i].flocation2,
        point : {
          point: {
            latitude : data.response[i].flocation1,
            longitude : data.response[i].flocation2
          }
        },
        ftid : data.response[i].ftid
      }
    }
  }
  else {
    var success = data.response[0].success;
    var len = data.response[0].length;
    for(var i = 1; i <= len; i++){
      console.log("data : " + data.response[i].ftid + ", t_result : " + DetailResult.travelId);
      if(data.response[i].ftid == DetailResult.travelId) {
        res[idx++] = {
          errorflag : "ok",
          fid : data.response[i].fid,
          fname : data.response[i].fname,
          fdate : data.response[i].fdate,
          flocation1 : data.response[i].flocation1,
          flocation2 : data.response[i].flocation2,
          point : {
            point: {
              latitude : data.response[i].flocation1,
              longitude : data.response[i].flocation2
            }
          },
          ftid : data.response[i].ftid
        }
      }
    }
  }

  
  
  return res;
}