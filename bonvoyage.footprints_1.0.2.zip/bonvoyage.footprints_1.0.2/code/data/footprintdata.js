module.exports = [
  {
    "response": [
        {
            "success": "true",
            "length": 5
        },
        {
            "fid": 1,
            "fname": "광안리",
            "fdate": "2019년 1월 1일",
            "flocation1": 37.239934,
            "flocation2": 127.058633,
            "ftid": 2
        },
        {
            "fid": 2,
            "fname": "해운대",
            "fdate": "2019년 2월 2일",
            "flocation1": 37.239934,
            "flocation2": 127.058633,
            "ftid": 2
        },
        {
            "fid": 3,
            "fname": "송정해수욕장",
            "fdate": "2019년 3월 3일",
            "flocation1": 37.239934,
            "flocation2": 127.058633,
            "ftid": 2
        },
        {
            "fid": 4,
            "fname": "호뚝발자취",
            "fdate": "2019년 2월 20일",
            "flocation1": 37.239934,
            "flocation2": 127.058633,
            "ftid": 1
        },
        {
            "fid": 5,
            "fname": "으아아아발자취",
            "fdate": "2019년 4월 20일",
            "flocation1": 37.239934,
            "flocation2": 127.058633,
            "ftid": 1
        }
    ]
  }
]