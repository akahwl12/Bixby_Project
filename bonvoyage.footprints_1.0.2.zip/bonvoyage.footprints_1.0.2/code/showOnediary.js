module.exports.function = function showOnediary ($vivContext, profile, TravelStructure) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };

  var onediaryParams = {
    "tid" : TravelStructure.travelId
  }; 

  let data = http.postUrl(baseUrl+'getOnediaryBytid.php', onediaryParams, options);

  var res = [];
  var success = data.response[0].success;
  var len = data.response[0].length;

  for(var i = 1; i <= len; i++){
    var odate = data.response[i].odate;
    var od = odate.split(' ')[0];
    var ot = odate.split(' ')[1];

    odate = od.substring(0,4) + "년 " + od.substring(5,7) + "월 " 
                    + od.substring(8,10) + "일 " + ot.substring(0,2) + "시 " + ot.substring(3,5) + "분";
    res[i-1] = {
      errorflag : "ok",
      oid : data.response[i].oid,
      odate : odate,
      olocation1 : data.response[i].olocation1,
      olocation2 : data.response[i].olocation2,
      point : {
        point: {
          latitude : data.response[i].olocation1,
          longitude : data.response[i].olocation2
        }
      },
      odiary : data.response[i].odiary,
      otid : data.response[i].otid
    }
  }

  return res;
}
