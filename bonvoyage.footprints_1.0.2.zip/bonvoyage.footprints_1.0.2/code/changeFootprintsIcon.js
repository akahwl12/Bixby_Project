module.exports.function = function changeFootprintsIcon ($vivContext, profile, footprintsIconResult) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');
  
  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      },
      cacheTime : 0
  };

  var params = {
    "fid" : footprintsIconResult.fid,
    "ficon" : footprintsIconResult.iconFileName
  }; 

  let data = http.postUrl(baseUrl+'updateFicon.php', params, options);

  console.log(data);
  
  var success = data.response[0].success;

  console.log(data.response[1].ficon);

  return {
    errorflag : "ok",
    fid : data.response[1].fid,
    fname : data.response[1].fname,
    fdate : data.response[1].fdate,
    flocation1 : data.response[1].flocation1,
    flocation2 : data.response[1].flocation2,
    point : {
      point: {
        latitude : data.response[1].flocation1,
        longitude : data.response[1].flocation2
      }
    },
    ftid : data.response[1].ftid,
    ficon : data.response[1].ficon
  };
}
