module.exports.function = function logout ($vivContext) {
  const config = require('config');
  const http = require('http');
  const fail = require('fail');
  const logoutURL = config.get("revokeURL");
  
  let result = false;
  var console = require('console');
  console.log($vivContext);
  if($vivContext.accessToken == null){
    throw fail.checkedError("No LogIn", "NoLogIn");
  }
  
  const url = "https://accounts.google.com/o/oauth2/revoke?token=" + $vivContext.accessToken;
  console.log(url);
  const response = http.getUrl(url, {format:"json", cacheTime: 0, returnHeaders:true});
  console.log(response);
  
  if(response.status != 200){
    throw fail.checkedError("Logout Failed", "LogoutFailed"); 
  }
  
  return "로그아웃 성공";
  
}
