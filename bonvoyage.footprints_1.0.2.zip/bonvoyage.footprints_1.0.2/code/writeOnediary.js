module.exports.function = function writeOnediary ($vivContext, odiary, point, profile, namewrite) {
  var console = require('console');
  const http = require('http');
  const config = require('config');
  const baseUrl = config.get("baseUrl");
  const fail = require('fail');

  let options = {
      format: 'json',
      headers: {
        'accept': 'application/json'
      }
  };

  var dates = require('dates');
  var zone = new dates.ZonedDateTime($vivContext.timezone);
  var odate = zone.getYear()+"-"+zone.getMonth()+"-"+zone.getDay();
  var otime = zone.getHour()+":"+zone.getMinute()+":"+zone.getSecond();
  var resultData = zone.getYear()+"년 "+zone.getMonth()+"월 "+zone.getDay()+"일 "+zone.getHour()+"시"+zone.getMinute()+"분";


  var onediaryParams = {
    "uemail": profile.email,
    "odate": odate,
    "otime": otime,
    "olocation1": point.point.latitude,
    "olocation2": point.point.longitude,
    "odiary" : odiary
  }; 

  let writeData = http.postUrl(baseUrl+'addOnediary.php', onediaryParams, options);

  var success = writeData.response[0].success;
  if(success == 'nottraveling'){
    return {
      errorflag : 'nottraveling'
    }
  }

  return {
      errorflag : 'ok',
      oid : 'tmp',
      odate : resultData,
      point : {
        point: {
          latitude : point.point.latitude,
          longitude : point.point.longitude
        }
      },
      odiary : odiary,
      otid : 'tmp'
  }
}